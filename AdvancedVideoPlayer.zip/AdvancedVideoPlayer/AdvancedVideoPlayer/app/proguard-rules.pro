# Keep FFmpeg-Kit
-keep class com.arthenica.** { *; }
-dontwarn com.arthenica.**

# Media3
-keep class androidx.media3.** { *; }
