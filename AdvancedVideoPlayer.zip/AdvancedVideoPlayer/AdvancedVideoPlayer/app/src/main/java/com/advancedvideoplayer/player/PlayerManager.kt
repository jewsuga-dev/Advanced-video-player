package com.advancedvideoplayer.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central player manager – closer to VLC feature set
 */
@OptIn(UnstableApi::class)
class PlayerManager(context: Context) {

    private val trackSelector = DefaultTrackSelector(context).apply {
        setParameters(
            buildUponParameters()
                .setPreferredAudioLanguage("en")
                .setPreferredTextLanguage("en")
        )
    }

    val player: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true // handle audio focus
        )
        .setHandleAudioBecomingNoisy(true)
        .build()

    // ===== State =====
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _audioTracks = MutableStateFlow<List<TrackInfo>>(emptyList())
    val audioTracks: StateFlow<List<TrackInfo>> = _audioTracks.asStateFlow()

    private val _subtitleTracks = MutableStateFlow<List<TrackInfo>>(emptyList())
    val subtitleTracks: StateFlow<List<TrackInfo>> = _subtitleTracks.asStateFlow()

    private val _selectedAudioId = MutableStateFlow<String?>(null)
    val selectedAudioId: StateFlow<String?> = _selectedAudioId.asStateFlow()

    private val _selectedSubtitleId = MutableStateFlow<String?>(null)
    val selectedSubtitleId: StateFlow<String?> = _selectedSubtitleId.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _videoResizeMode = MutableStateFlow(ResizeMode.FIT)
    val videoResizeMode: StateFlow<ResizeMode> = _videoResizeMode.asStateFlow()

    data class TrackInfo(
        val id: String,
        val name: String,
        val language: String,
        val codec: String = "",
        val channels: Int = 0,
        val isSelected: Boolean = false
    )

    enum class ResizeMode {
        FIT, FILL, ZOOM, STRETCH
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _duration.value = player.duration.coerceAtLeast(0)
        }

        override fun onTracksChanged(tracks: Tracks) {
            updateTrackLists(tracks)
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            _playbackSpeed.value = playbackParameters.speed
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeatMode.value = repeatMode
        }
    }

    init {
        player.addListener(listener)
    }

    fun load(uri: Uri) {
        val mediaItem = MediaItem.fromUri(uri)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true
    }

    fun play() = player.play()
    fun pause() = player.pause()
    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun seekTo(positionMs: Long) = player.seekTo(positionMs)
    fun seekBy(deltaMs: Long) = player.seekTo(player.currentPosition + deltaMs)

    fun setSpeed(speed: Float) {
        player.playbackParameters = PlaybackParameters(speed)
        _playbackSpeed.value = speed
    }

    fun cycleSpeed() {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val current = _playbackSpeed.value
        val next = speeds[(speeds.indexOfFirst { it >= current } + 1) % speeds.size]
        setSpeed(next)
    }

    fun setRepeatMode(mode: Int) {
        player.repeatMode = mode
    }

    fun cycleRepeatMode() {
        val next = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        player.repeatMode = next
    }

    fun selectAudioTrack(trackId: String) {
        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val id = format.id ?: continue
                if (id == trackId) {
                    trackSelector.setParameters(
                        trackSelector.buildUponParameters()
                            .setOverrideForType(
                                TrackSelectionOverride(group.mediaTrackGroup, i)
                            )
                    )
                    _selectedAudioId.value = trackId
                    return
                }
            }
        }
    }

    fun selectSubtitleTrack(trackId: String?) {
        if (trackId == null) {
            // Disable subtitles
            trackSelector.setParameters(
                trackSelector.buildUponParameters()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            )
            _selectedSubtitleId.value = null
            return
        }

        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val id = format.id ?: continue
                if (id == trackId) {
                    trackSelector.setParameters(
                        trackSelector.buildUponParameters()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(
                                TrackSelectionOverride(group.mediaTrackGroup, i)
                            )
                    )
                    _selectedSubtitleId.value = trackId
                    return
                }
            }
        }
    }

    fun setResizeMode(mode: ResizeMode) {
        _videoResizeMode.value = mode
    }

    fun cycleResizeMode() {
        val values = ResizeMode.entries
        val next = values[(_videoResizeMode.value.ordinal + 1) % values.size]
        _videoResizeMode.value = next
    }

    fun updatePosition() {
        _position.value = player.currentPosition
        _duration.value = player.duration.coerceAtLeast(0)
    }

    private fun updateTrackLists(tracks: Tracks) {
        val audioList = mutableListOf<TrackInfo>()
        val subList = mutableListOf<TrackInfo>()

        for (group in tracks.groups) {
            when (group.type) {
                C.TRACK_TYPE_AUDIO -> {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val id = format.id ?: "audio_$i"
                        val lang = format.language ?: ""
                        val channels = format.channelCount
                        val name = buildString {
                            if (lang.isNotEmpty()) append(lang.uppercase())
                            if (channels > 0) {
                                if (isNotEmpty()) append(" • ")
                                append("${channels}ch")
                            }
                            if (format.codecs != null) {
                                if (isNotEmpty()) append(" • ")
                                append(format.codecs)
                            }
                            if (isEmpty()) append("Track ${i + 1}")
                        }
                        audioList.add(
                            TrackInfo(
                                id = id,
                                name = name,
                                language = lang,
                                codec = format.codecs ?: "",
                                channels = channels,
                                isSelected = group.isTrackSelected(i)
                            )
                        )
                        if (group.isTrackSelected(i)) {
                            _selectedAudioId.value = id
                        }
                    }
                }
                C.TRACK_TYPE_TEXT -> {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val id = format.id ?: "sub_$i"
                        val lang = format.language ?: ""
                        val name = when {
                            !format.label.isNullOrEmpty() -> format.label!!
                            lang.isNotEmpty() -> lang.uppercase()
                            else -> "Subtitle ${i + 1}"
                        }
                        subList.add(
                            TrackInfo(
                                id = id,
                                name = name,
                                language = lang,
                                isSelected = group.isTrackSelected(i)
                            )
                        )
                        if (group.isTrackSelected(i)) {
                            _selectedSubtitleId.value = id
                        }
                    }
                }
            }
        }
        _audioTracks.value = audioList
        _subtitleTracks.value = subList
    }

    fun release() {
        player.removeListener(listener)
        player.release()
    }
}
