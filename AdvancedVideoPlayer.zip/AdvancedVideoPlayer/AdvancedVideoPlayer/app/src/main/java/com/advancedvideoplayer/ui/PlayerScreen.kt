package com.advancedvideoplayer.ui

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.advancedvideoplayer.data.MediaMetadata
import com.advancedvideoplayer.data.MetadataExtractor
import com.advancedvideoplayer.data.SpecialFormat
import com.advancedvideoplayer.player.PlayerManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    videoUri: Uri?,
    onOpenFile: () -> Unit,
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val playerManager = remember { PlayerManager(context) }
    val exoPlayer = playerManager.player

    var metadata by remember { mutableStateOf<MediaMetadata?>(null) }
    var isLoadingMeta by remember { mutableStateOf(false) }

    var controlsVisible by remember { mutableStateOf(true) }
    var showMetadataPanel by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showSubtitleTracks by remember { mutableStateOf(false) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showSpecialLogos by remember { mutableStateOf(false) }
    var gestureText by remember { mutableStateOf<String?>(null) }
    var logosShownForThisVideo by remember { mutableStateOf(false) }

    val isPlaying by playerManager.isPlaying.collectAsState()
    val position by playerManager.position.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val speed by playerManager.playbackSpeed.collectAsState()
    val audioTracks by playerManager.audioTracks.collectAsState()
    val subtitleTracks by playerManager.subtitleTracks.collectAsState()
    val selectedAudioId by playerManager.selectedAudioId.collectAsState()
    val selectedSubtitleId by playerManager.selectedSubtitleId.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val resizeMode by playerManager.videoResizeMode.collectAsState()

    // Load media + metadata
    LaunchedEffect(videoUri) {
        if (videoUri != null) {
            isLoadingMeta = true
            metadata = null
            logosShownForThisVideo = false
            showSpecialLogos = false
            playerManager.load(videoUri)
            scope.launch {
                metadata = MetadataExtractor.extract(context, videoUri)
                isLoadingMeta = false
            }
        }
    }

    // Show logos when metadata first becomes available (video starts)
    LaunchedEffect(metadata) {
        if (metadata != null && metadata!!.specialFormats.isNotEmpty() && !logosShownForThisVideo) {
            showSpecialLogos = true
            logosShownForThisVideo = true
            delay(6000) // stay for 6 seconds
            showSpecialLogos = false
        }
    }

    // Show logos again every time the user pauses
    LaunchedEffect(isPlaying) {
        if (!isPlaying && metadata?.specialFormats?.isNotEmpty() == true) {
            showSpecialLogos = true
            delay(6000)
            showSpecialLogos = false
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            playerManager.updatePosition()
            delay(200)
        }
    }

    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(4000)
            controlsVisible = false
        }
    }

    DisposableEffect(Unit) {
        onDispose { playerManager.release() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { controlsVisible = !controlsVisible },
                    onDoubleTap = { offset ->
                        val width = size.width
                        when {
                            offset.x < width / 3 -> {
                                playerManager.seekBy(-10000)
                                gestureText = "« 10s"
                            }
                            offset.x > width * 2 / 3 -> {
                                playerManager.seekBy(10000)
                                gestureText = "10s »"
                            }
                            else -> playerManager.togglePlayPause()
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    change.consume()
                    if (abs(dragAmount) > 5) {
                        gestureText = if (dragAmount < 0) "Brightness ↑" else "Brightness ↓"
                    }
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    if (abs(dragAmount) > 15) {
                        playerManager.seekBy((dragAmount * 50).toLong())
                        gestureText = if (dragAmount > 0) "Seeking »" else "« Seeking"
                    }
                }
            }
    ) {
        if (videoUri != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { view ->
                    view.resizeMode = when (resizeMode) {
                        PlayerManager.ResizeMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        PlayerManager.ResizeMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        PlayerManager.ResizeMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        PlayerManager.ResizeMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            EmptyState(onOpenFile = onOpenFile)
        }

        // Gesture feedback
        AnimatedVisibility(
            visible = gestureText != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(color = Color.Black.copy(0.7f), shape = RoundedCornerShape(12.dp)) {
                Text(
                    gestureText ?: "",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                )
            }
            LaunchedEffect(gestureText) {
                delay(800)
                gestureText = null
            }
        }

        // Special logos
        AnimatedVisibility(
            visible = showSpecialLogos && metadata?.specialFormats?.isNotEmpty() == true,
            enter = fadeIn() + slideInHorizontally { it },
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.End) {
                metadata?.specialFormats?.forEach { SpecialFormatBadge(it) }
            }
        }

        // Top bar
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            TopBar(
                title = metadata?.fileName ?: "Advanced Video Player",
                onOpenFile = onOpenFile,
                onToggleMetadata = { showMetadataPanel = !showMetadataPanel },
                onMore = { showMoreMenu = true }
            )
        }

        // Bottom controls
        AnimatedVisibility(
            visible = controlsVisible && videoUri != null,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            BottomControls(
                isPlaying = isPlaying,
                position = position,
                duration = duration,
                speed = speed,
                repeatMode = repeatMode,
                onPlayPause = { playerManager.togglePlayPause() },
                onSeek = { playerManager.seekTo(it) },
                onSeekBack = { playerManager.seekBy(-10000) },
                onSeekForward = { playerManager.seekBy(10000) },
                onSpeed = { showSpeedMenu = true },
                onAudio = { showAudioTracks = true },
                onSubtitle = { showSubtitleTracks = true },
                onRepeat = { playerManager.cycleRepeatMode() },
                onResize = { playerManager.cycleResizeMode() }
            )
        }

        if (showAudioTracks) {
            TrackSelectionSheet(
                title = "Audio Tracks",
                tracks = audioTracks.map { it.id to it.name },
                selectedId = selectedAudioId,
                onSelect = { playerManager.selectAudioTrack(it!!); showAudioTracks = false },
                onDismiss = { showAudioTracks = false }
            )
        }

        if (showSubtitleTracks) {
            TrackSelectionSheet(
                title = "Subtitles",
                tracks = listOf(null to "Off") + subtitleTracks.map { it.id to it.name },
                selectedId = selectedSubtitleId,
                onSelect = { playerManager.selectSubtitleTrack(it); showSubtitleTracks = false },
                onDismiss = { showSubtitleTracks = false }
            )
        }

        if (showSpeedMenu) {
            SpeedSheet(
                current = speed,
                onSelect = { playerManager.setSpeed(it); showSpeedMenu = false },
                onDismiss = { showSpeedMenu = false }
            )
        }

        if (showMoreMenu) {
            MoreMenu(
                onDismiss = { showMoreMenu = false },
                onToggleLogos = { showSpecialLogos = !showSpecialLogos },
                onToggleMetadata = { showMoreMenu = false; showMetadataPanel = true }
            )
        }

        AnimatedVisibility(
            visible = showMetadataPanel,
            enter = slideInHorizontally { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            MetadataPanel(metadata = metadata, isLoading = isLoadingMeta, onClose = { showMetadataPanel = false })
        }

        if (isLoadingMeta) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center).size(48.dp),
                color = Color(0xFFFF4D6D),
                strokeWidth = 3.dp
            )
        }
    }
}

@Composable
private fun EmptyState(onOpenFile: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.VideoLibrary, null, modifier = Modifier.size(96.dp), tint = Color.White.copy(0.3f))
        Spacer(Modifier = Modifier.height(20.dp))
        Text("Open a video or audio file", color = Color.White.copy(0.7f), fontSize = 18.sp)
        Spacer(Modifier = Modifier.height(6.dp))
        Text("MKV • MP4 • TS • DTS:X • Atmos • TrueHD • DV", color = Color.White.copy(0.4f), fontSize = 13.sp)
        Spacer(Modifier = Modifier.height(28.dp))
        Button(
            onClick = onOpenFile,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4D6D)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.FolderOpen, null)
            Spacer(Modifier = Modifier.width(8.dp))
            Text("Open File")
        }
    }
}

@Composable
private fun TopBar(title: String, onOpenFile: () -> Unit, onToggleMetadata: () -> Unit, onMore: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(0.8f), Color.Transparent)))
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        IconButton(onClick = onToggleMetadata) { Icon(Icons.Default.Info, null, tint = Color.White) }
        IconButton(onClick = onOpenFile) { Icon(Icons.Default.FolderOpen, null, tint = Color.White) }
        IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
    }
}

@Composable
private fun BottomControls(
    isPlaying: Boolean, position: Long, duration: Long, speed: Float, repeatMode: Int,
    onPlayPause: () -> Unit, onSeek: (Long) -> Unit, onSeekBack: () -> Unit, onSeekForward: () -> Unit,
    onSpeed: () -> Unit, onAudio: () -> Unit, onSubtitle: () -> Unit, onRepeat: () -> Unit, onResize: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.85f))))
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime(position), color = Color.White.copy(0.8f), fontSize = 11.sp)
            Slider(
                value = if (duration > 0) position.toFloat() / duration else 0f,
                onValueChange = { onSeek((it * duration).toLong()) },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFFF4D6D),
                    activeTrackColor = Color(0xFFFF4D6D),
                    inactiveTrackColor = Color.White.copy(0.25f)
                )
            )
            Text(formatTime(duration), color = Color.White.copy(0.8f), fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onRepeat) {
                Icon(
                    when (repeatMode) {
                        Player.REPEAT_MODE_ONE -> Icons.Default.RepeatOne
                        Player.REPEAT_MODE_ALL -> Icons.Default.Repeat
                        else -> Icons.Default.Repeat
                    }, null, tint = if (repeatMode != Player.REPEAT_MODE_OFF) Color(0xFFFF4D6D) else Color.White
                )
            }
            IconButton(onClick = onSeekBack) {
                Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(56.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = onSeekForward) {
                Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            TextButton(onClick = onSpeed) {
                Text("${speed}x", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onAudio) {
                Icon(Icons.Default.Audiotrack, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier = Modifier.width(4.dp))
                Text("Audio", color = Color.White, fontSize = 12.sp)
            }
            TextButton(onClick = onSubtitle) {
                Icon(Icons.Default.ClosedCaption, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier = Modifier.width(4.dp))
                Text("Subs", color = Color.White, fontSize = 12.sp)
            }
            TextButton(onClick = onResize) {
                Icon(Icons.Default.AspectRatio, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier = Modifier.width(4.dp))
                Text("Fit", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TrackSelectionSheet(
    title: String,
    tracks: List<Pair<String?, String>>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(tracks.size) { i ->
                    val (id, name) = tracks[i]
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(id) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = id == selectedId, onClick = { onSelect(id) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(name)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SpeedSheet(current: Float, onSelect: (Float) -> Unit, onDismiss: () -> Unit) {
    val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback Speed") },
        text = {
            Column {
                speeds.forEach { s ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(s) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = s == current, onClick = { onSelect(s) })
                        Spacer(Modifier = Modifier.width(8.dp))
                        Text(if (s == 1.0f) "Normal" else "${s}x")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun MoreMenu(onDismiss: () -> Unit, onToggleLogos: () -> Unit, onToggleMetadata: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("More Options") },
        text = {
            Column {
                TextButton(onClick = onToggleLogos, modifier = Modifier.fillMaxWidth()) { Text("Toggle Format Logos") }
                TextButton(onClick = onToggleMetadata, modifier = Modifier.fillMaxWidth()) { Text("Media Information") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SpecialFormatBadge(format: SpecialFormat) {
    val context = LocalContext.current
    val bg = when (format) {
        SpecialFormat.DOLBY_VISION, SpecialFormat.DOLBY_ATMOS, SpecialFormat.TRUEHD -> Color(0xFF00B4E4)
        SpecialFormat.DTS_X, SpecialFormat.DTS_HD, SpecialFormat.DTS -> Color(0xFFE31C25)
        SpecialFormat.HDR10, SpecialFormat.HDR10_PLUS -> Color(0xFFFFD700)
        else -> Color(0xFF7B61FF)
    }

    // Try loading real image logo from assets.
    // If missing or fails → automatically falls back to colored text badge.
    SubcomposeAsyncImage(
        model = ImageRequest.Builder(context)
            .data("file:///android_asset/${format.logoAsset}")
            .crossfade(true)
            .build(),
        contentDescription = format.displayName,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .height(28.dp)
            .padding(vertical = 2.dp),
        loading = { /* show nothing while loading */ },
        error = {
            // Safe fallback – never crashes
            Surface(
                color = bg,
                shape = RoundedCornerShape(6.dp),
                shadowElevation = 4.dp
            ) {
                Text(
                    text = format.displayName,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    )
}

@Composable
private fun MetadataPanel(metadata: MediaMetadata?, isLoading: Boolean, onClose: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxHeight().width(320.dp).padding(top = 48.dp, bottom = 12.dp, end = 8.dp),
        color = Color(0xFF121212).copy(alpha = 0.96f),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Media Info", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
            }
            HorizontalDivider(color = Color.White.copy(0.1f))
            Spacer(modifier = Modifier.height(8.dp))
            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFFFF4D6D))
                }
            } else if (metadata == null) {
                Text("No metadata", color = Color.Gray)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("File", color = Color(0xFFFF4D6D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        MetaLine("Name", metadata.fileName)
                        MetaLine("Format", metadata.formatLong.ifEmpty { metadata.format })
                        MetaLine("Duration", formatTime(metadata.durationMs))
                        MetaLine("Size", formatSize(metadata.sizeBytes))
                    }
                    if (metadata.specialFormats.isNotEmpty()) {
                        item {
                            Text("Special", color = Color(0xFFFF4D6D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            metadata.specialFormats.forEach {
                                Text("★ ${it.displayName}", color = Color(0xFFFF4D6D), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    items(metadata.videoTracks) { t ->
                        Text("Video #${t.index}", color = Color(0xFFFF4D6D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        MetaLine("Codec", t.codecLong.ifEmpty { t.codec })
                        MetaLine("Resolution", "${t.width}×${t.height}")
                        MetaLine("FPS", "%.3f".format(t.frameRate))
                        if (t.isDolbyVision) MetaLine("Dolby Vision", "Profile ${t.dvProfile}")
                        if (t.isHdr) MetaLine("HDR", "Yes")
                    }
                    items(metadata.audioTracks) { t ->
                        Text("Audio #${t.index}", color = Color(0xFFFF4D6D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        MetaLine("Codec", t.codecLong.ifEmpty { t.codec })
                        MetaLine("Channels", "${t.channels} (${t.channelLayout})")
                        MetaLine("Sample Rate", "${t.sampleRate} Hz")
                        if (t.isDtsX) Text("★ DTS:X", color = Color(0xFFE31C25), fontWeight = FontWeight.Bold)
                        if (t.isAtmos) Text("★ Dolby Atmos", color = Color(0xFF00B4E4), fontWeight = FontWeight.Bold)
                        if (t.isTrueHd) Text("★ TrueHD", color = Color(0xFF00B4E4), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetaLine(label: String, value: String) {
    Row(modifier = Modifier.padding(vertical = 1.dp)) {
        Text(label, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(90.dp))
        Text(value, color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "—"
    val mb = bytes / 1024.0 / 1024.0
    val gb = mb / 1024.0
    return if (gb >= 1) "%.2f GB".format(gb) else "%.1f MB".format(mb)
}
