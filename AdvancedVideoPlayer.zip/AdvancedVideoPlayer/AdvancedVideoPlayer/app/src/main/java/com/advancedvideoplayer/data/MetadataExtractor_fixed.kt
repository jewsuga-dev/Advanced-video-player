package com.advancedvideoplayer.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.MediaInformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

object MetadataExtractor {

    private const val TAG = "MetadataExtractor"

    /**
     * Extract rich metadata using FFprobe (from FFmpeg-Kit)
     */
    suspend fun extract(context: Context, uri: Uri): MediaMetadata = withContext(Dispatchers.IO) {
        try {
            // Copy content URI to a temporary file so FFprobe can read it
            val tempFile = copyUriToTempFile(context, uri)
            val path = tempFile.absolutePath

            val session = FFprobeKit.getMediaInformation(path)
            val info = session.mediaInformation

            if (info == null) {
                Log.e(TAG, "FFprobe returned null media information")
                return@withContext MediaMetadata(fileName = getFileName(context, uri))
            }

            val metadata = parseMediaInformation(info, getFileName(context, uri))

            // Clean up temp file
            tempFile.delete()

            metadata
        } catch (e: Exception) {
            Log.e(TAG, "Failed to extract metadata", e)
            MediaMetadata(fileName = getFileName(context, uri))
        }
    }

    private fun copyUriToTempFile(context: Context, uri: Uri): File {
        val temp = File(context.cacheDir, "ffprobe_temp_${System.currentTimeMillis()}")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(temp).use { output ->
                input.copyTo(output)
            }
        }
        return temp
    }

    private fun getFileName(context: Context, uri: Uri): String {
        var name = "Unknown"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex) ?: "Unknown"
            }
        }
        return name
    }

    private fun parseMediaInformation(info: MediaInformation, fileName: String): MediaMetadata {
        val format = info.format ?: ""
        val formatLong = info.getStringFormatProperty("format_long_name") ?: format
        val duration = ((info.duration?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
        val size = info.size?.toLongOrNull() ?: 0L
        val bitrate = info.bitrate?.toLongOrNull() ?: 0L

        val videoTracks = mutableListOf<TrackInfo>()
        val audioTracks = mutableListOf<TrackInfo>()
        val subtitleTracks = mutableListOf<TrackInfo>()
        val special = mutableSetOf<SpecialFormat>()

        val streams = info.streams ?: emptyList()

        streams.forEachIndexed { index, stream ->
            val type = stream.type ?: ""
            val codec = (stream.codec ?: "").lowercase()
            val codecLong = stream.getStringProperty("codec_long_name") ?: codec
            val tags = stream.tags
            val language = tags?.optString("language", "") ?: ""
            val title = tags?.optString("title", "") ?: ""

            when (type.lowercase()) {
                "video" -> {
                    val width = stream.width?.toIntOrNull() ?: 0
                    val height = stream.height?.toIntOrNull() ?: 0
                    val fps = stream.averageFrameRate?.let { parseFps(it) } ?: 0f
                    val profile = stream.getStringProperty("profile") ?: ""
                    val pixFmt = stream.getStringProperty("pix_fmt") ?: ""

                    // Color info
                    val colorSpace = stream.getStringProperty("color_space") ?: ""
                    val colorTransfer = stream.getStringProperty("color_transfer") ?: ""
                    val colorPrimaries = stream.getStringProperty("color_primaries") ?: ""

                    val isHdr = colorTransfer.contains("smpte2084", true) ||
                            colorTransfer.contains("arib-std-b67", true) ||
                            colorTransfer.contains("hlg", true) ||
                            pixFmt.contains("p10", true) || pixFmt.contains("p12", true)

                    // Dolby Vision detection
                    val isDolbyVision = codec.contains("dolby", true) ||
                            codec.contains("dvhe", true) ||
                            codec.contains("dvh1", true) ||
                            profile.contains("dv", true) ||
                            stream.getStringProperty("side_data_list")?.contains("DOVI", true) == true ||
                            stream.getStringProperty("codec_tag_string")?.contains("dvh", true) == true

                    var dvProfile = ""
                    if (isDolbyVision) {
                        // Try to extract DV profile (common values: 5, 8.1, 8.4, etc.)
                        dvProfile = stream.getStringProperty("dv_profile")
                            ?: stream.getStringProperty("profile")
                            ?: "Unknown"
                        special.add(SpecialFormat.DOLBY_VISION)
                    }

                    if (isHdr && !isDolbyVision) {
                        when {
                            colorTransfer.contains("smpte2084", true) -> special.add(SpecialFormat.HDR10)
                            colorTransfer.contains("arib-std-b67", true) ||
                                    colorTransfer.contains("hlg", true) -> special.add(SpecialFormat.HLG)
                        }
                    }

                    if (codec.contains("av1", true)) special.add(SpecialFormat.AV1)
                    if (codec.contains("hevc", true) || codec.contains("h265", true)) {
                        special.add(SpecialFormat.HEVC)
                    }

                    videoTracks.add(
                        TrackInfo(
                            index = index,
                            type = "video",
                            codec = codec,
                            codecLong = codecLong,
                            language = language,
                            title = title,
                            bitrate = stream.bitrate?.toLongOrNull() ?: 0,
                            width = width,
                            height = height,
                            frameRate = fps,
                            profile = profile,
                            pixFmt = pixFmt,
                            colorSpace = colorSpace,
                            colorTransfer = colorTransfer,
                            colorPrimaries = colorPrimaries,
                            isHdr = isHdr,
                            isDolbyVision = isDolbyVision,
                            dvProfile = dvProfile
                        )
                    )
                }

                "audio" -> {
                    val channels = stream.channelLayout?.let { parseChannels(it) }
                        ?: stream.getStringProperty("channels")?.toIntOrNull()
                        ?: 0
                    val sampleRate = stream.sampleRate?.toIntOrNull() ?: 0
                    val channelLayout = stream.channelLayout ?: ""
                    val profile = stream.getStringProperty("profile") ?: ""

                    // ----- Special audio format detection -----
                    val isTrueHd = codec.contains("truehd", true) || codec.contains("mlp", true)
                    val isAtmos = isTrueHd && (
                            profile.contains("atmos", true) ||
                                    channelLayout.contains("atmos", true) ||
                                    title.contains("atmos", true) ||
                                    stream.getStringProperty("codec_tag_string")?.contains("atmos", true) == true
                            ) ||
                            codec.contains("eac3", true) && title.contains("atmos", true)

                    val isDtsX = codec.contains("dts", true) && (
                            profile.contains("x", true) ||
                                    profile.contains("dts:x", true) ||
                                    title.contains("dts:x", true) ||
                                    title.contains("dtsx", true) ||
                                    channelLayout.contains("x", true)
                            )

                    val isDtsHd = codec.contains("dts", true) && (
                            profile.contains("hd", true) ||
                                    profile.contains("ma", true) ||
                                    profile.contains("hra", true) ||
                                    title.contains("dts-hd", true) ||
                                    title.contains("dts hd", true)
                            ) && !isDtsX

                    val isDts = codec.contains("dts", true) && !isDtsHd && !isDtsX
                    val isDdp = codec.contains("eac3", true) || codec.contains("ec-3", true)
                    val isAac = codec.contains("aac", true)

                    if (isAtmos) special.add(SpecialFormat.DOLBY_ATMOS)
                    if (isTrueHd) special.add(SpecialFormat.TRUEHD)
                    if (isDtsX) special.add(SpecialFormat.DTS_X)
                    if (isDtsHd) special.add(SpecialFormat.DTS_HD)
                    if (isDts) special.add(SpecialFormat.DTS)
                    if (isDdp) special.add(SpecialFormat.DOLBY_DIGITAL_PLUS)

                    audioTracks.add(
                        TrackInfo(
                            index = index,
                            type = "audio",
                            codec = codec,
                            codecLong = codecLong,
                            language = language,
                            title = title,
                            bitrate = stream.bitrate?.toLongOrNull() ?: 0,
                            channels = channels,
                            sampleRate = sampleRate,
                            channelLayout = channelLayout,
                            profile = profile,
                            isAtmos = isAtmos,
                            isTrueHd = isTrueHd,
                            isDts = isDts,
                            isDtsHd = isDtsHd,
                            isDtsX = isDtsX,
                            isDolbyDigitalPlus = isDdp,
                            isAac = isAac
                        )
                    )
                }

                "subtitle" -> {
                    subtitleTracks.add(
                        TrackInfo(
                            index = index,
                            type = "subtitle",
                            codec = codec,
                            codecLong = codecLong,
                            language = language,
                            title = title
                        )
                    )
                }
            }
        }

        return MediaMetadata(
            fileName = fileName,
            format = format,
            formatLong = formatLong,
            durationMs = duration,
            sizeBytes = size,
            bitrate = bitrate,
            videoTracks = videoTracks,
            audioTracks = audioTracks,
            subtitleTracks = subtitleTracks,
            specialFormats = special.toList()
        )
    }

    private fun parseFps(rate: String): Float {
        return try {
            if (rate.contains("/")) {
                val parts = rate.split("/")
                parts[0].toFloat() / parts[1].toFloat()
            } else {
                rate.toFloat()
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun parseChannels(layout: String): Int {
        // Simple heuristic
        return when {
            layout.contains("7.1", true) -> 8
            layout.contains("5.1", true) -> 6
            layout.contains("stereo", true) || layout.contains("2.0", true) -> 2
            layout.contains("mono", true) -> 1
            else -> layout.count { it == '.' || it.isDigit() }.coerceAtLeast(2)
        }
    }
}
