package com.advancedvideoplayer.data

/**
 * Rich media information extracted mainly via FFmpeg
 */
data class TrackInfo(
    val index: Int,
    val type: String,          // video / audio / subtitle
    val codec: String,
    val codecLong: String = "",
    val language: String = "",
    val title: String = "",
    val bitrate: Long = 0,
    val channels: Int = 0,
    val sampleRate: Int = 0,
    val channelLayout: String = "",
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val bitDepth: Int = 0,
    val profile: String = "",
    val level: String = "",
    val pixFmt: String = "",
    val colorSpace: String = "",
    val colorTransfer: String = "",
    val colorPrimaries: String = "",
    val isHdr: Boolean = false,
    val isDolbyVision: Boolean = false,
    val dvProfile: String = "",
    val isAtmos: Boolean = false,
    val isTrueHd: Boolean = false,
    val isDts: Boolean = false,
    val isDtsHd: Boolean = false,
    val isDtsX: Boolean = false,
    val isDolbyDigitalPlus: Boolean = false,
    val isAac: Boolean = false,
    val extra: Map<String, String> = emptyMap()
)

data class MediaMetadata(
    val fileName: String = "",
    val format: String = "",
    val formatLong: String = "",
    val durationMs: Long = 0,
    val sizeBytes: Long = 0,
    val bitrate: Long = 0,
    val videoTracks: List<TrackInfo> = emptyList(),
    val audioTracks: List<TrackInfo> = emptyList(),
    val subtitleTracks: List<TrackInfo> = emptyList(),
    val specialFormats: List<SpecialFormat> = emptyList()
)

enum class SpecialFormat(val displayName: String, val logoAsset: String) {
    DOLBY_VISION("Dolby Vision", "logos/dolby_vision.png"),
    DOLBY_ATMOS("Dolby Atmos", "logos/dolby_atmos.png"),
    TRUEHD("Dolby TrueHD", "logos/truehd.png"),
    DTS("DTS", "logos/dts.png"),
    DTS_HD("DTS-HD", "logos/dts_hd.png"),
    DTS_X("DTS:X", "logos/dts_x.png"),
    DOLBY_DIGITAL_PLUS("Dolby Digital Plus", "logos/ddp.png"),
    HDR10("HDR10", "logos/hdr10.png"),
    HDR10_PLUS("HDR10+", "logos/hdr10plus.png"),
    HLG("HLG", "logos/hlg.png"),
    AV1("AV1", "logos/av1.png"),
    HEVC("HEVC / H.265", "logos/hevc.png")
}
