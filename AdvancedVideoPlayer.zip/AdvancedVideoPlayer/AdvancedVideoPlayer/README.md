# Advanced Video Player (Android)

A feature-rich Android video player inspired by VLC, built with **Media3 (ExoPlayer)** + **FFmpeg-Kit**.

---

## Features (VLC-like)

### Playback
- Play local video / audio files (MP4, MKV, TS, M2TS, AVI, etc.)
- Play / Pause / Seek
- Double-tap left/right → ±10 seconds
- Horizontal swipe → seek
- Vertical swipe → brightness feedback
- Playback speed: 0.25x → 3.0x
- Repeat modes: Off / One / All
- Aspect ratio modes: Fit / Fill / Zoom / Stretch

### Tracks
- **Audio track selection** (with codec & channel info)
- **Subtitle track selection** (including Off)

### Metadata & Special Formats
- Deep metadata via FFmpeg (container, codecs, bitrate, resolution, HDR, etc.)
- Automatic detection + logo badges for:
  - Dolby Vision (with profile)
  - Dolby Atmos
  - Dolby TrueHD
  - DTS / DTS-HD / **DTS:X**
  - HDR10 / HLG
  - AV1 / HEVC
- Side panel with full media information

### UI
- Modern dark Material 3 interface
- Auto-hiding controls
- Gesture feedback overlays
- Open files from other apps

---

## Important Limitations (same as VLC on Android)

| Feature                        | Status                          |
|--------------------------------|---------------------------------|
| DTS:X / TrueHD **detection**   | Excellent                       |
| DTS:X / TrueHD **playback**    | Not possible on most phones     |
| Bit-perfect output             | Not possible on Android         |
| 24-bit lossless detection      | Yes                             |
| 24-bit lossless playback       | Partial (device dependent)      |

---

## Requirements

- Android Studio Ladybug (2024.2+) or newer
- JDK 17
- Device / emulator with API 26+

---

## How to Build

### Android Studio
1. Open the `AdvancedVideoPlayer` folder
2. Wait for Gradle sync
3. Run on device/emulator

### Terminal
```bash
cd AdvancedVideoPlayer
chmod +x gradlew          # first time
./gradlew assembleDebug
./gradlew installDebug
```

APK location:  
`app/build/outputs/apk/debug/app-debug.apk`

---

## Project Structure

```
app/src/main/java/com/advancedvideoplayer/
├── MainActivity.kt
├── player/
│   └── PlayerManager.kt          ← ExoPlayer wrapper + track selection
├── data/
│   ├── MediaInfo.kt              ← data classes + SpecialFormat
│   └── MetadataExtractor.kt      ← FFmpeg metadata + format detection
└── ui/
    ├── PlayerScreen.kt           ← main UI + gestures + menus
    └── theme/Theme.kt
```

---

## Adding Custom Logos

Put PNG files in:
```
app/src/main/assets/logos/
├── dts_x.png
├── dolby_atmos.png
├── truehd.png
├── dolby_vision.png
└── ...
```

Then the badges can be switched from colored text to real images.

---

Enjoy!
